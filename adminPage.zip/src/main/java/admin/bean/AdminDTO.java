package admin.bean;

import lombok.Data;

@Data
public class AdminDTO {
	private String adminId;
	private String adminPwd;
	private String adminEmail;
	private String adminProfile;
	
}

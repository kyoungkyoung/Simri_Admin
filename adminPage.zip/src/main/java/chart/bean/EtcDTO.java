package chart.bean;

import lombok.Data;

@Data
public class EtcDTO {
	private int seq;
	private String etcLogtime;
	private int hitHit;
	private int likeLike;
	private int shareShare;
}

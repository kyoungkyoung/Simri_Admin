package post.dao;

public interface PostDAO {

}

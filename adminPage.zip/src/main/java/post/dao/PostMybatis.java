package post.dao;

public class PostMybatis implements PostDAO {

}

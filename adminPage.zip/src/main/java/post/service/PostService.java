package post.service;

public interface PostService {

}

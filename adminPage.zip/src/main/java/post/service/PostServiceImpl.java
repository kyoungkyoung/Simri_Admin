package post.service;

public class PostServiceImpl implements PostService {

}
